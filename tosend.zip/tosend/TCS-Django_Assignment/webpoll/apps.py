from django.apps import AppConfig


class WebpollConfig(AppConfig):
    name = 'webpoll'
