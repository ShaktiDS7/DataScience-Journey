===========
Using celery to perform imports
===========

You can use the 3rd party `django-import-export-celery <https://github.com/auto-mat/django-import-export-celery>`_ application to process long imports in celery.
