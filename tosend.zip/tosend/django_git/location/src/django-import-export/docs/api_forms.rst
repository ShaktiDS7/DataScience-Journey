=====
Forms
=====

.. module:: import_export.forms

.. autoclass:: ImportForm

.. autoclass:: ConfirmImportForm
